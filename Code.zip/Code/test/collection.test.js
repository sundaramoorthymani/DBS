const chai = require('chai');
const expect = chai.expect;

const { LeastFrequentCollection } = require('../collection');

const mockData = {
  "timestamp": "2019-05-05T18:05:43.515Z",
  "symbol": "A05.SI",
  "sharesTraded": "5k",
  "priceTraded": 26.55,
  "changeDirection": "up",
  "changeAmount": 0.17
}

describe("Test Collections", () => {

  it("should return 3 unique symbols within in 10 minutes if it has less than 5 symbols", () => {
    const lfu = new LeastFrequentCollection(5);
    const testData = []
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:05:43.515Z",
      symbol: "A05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:06:43.515Z",
      symbol: "B05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:07:43.515Z",
      symbol: "C05.SI"
    })

    testData.forEach(element => {
        lfu.put(element);
    }); 

    const response = lfu.getRecentSymbols("2019-05-05T18:11:43.515Z")
    expect(response.length).is.equal(3);
    expect(response[0].symbol).is.equal("C05.SI");
    expect(response[1].symbol).is.equal("B05.SI");
    expect(response[2].symbol).is.equal("A05.SI");
  })

  it("should return max 5 unique symbols within in 10 minutes if it has more than 5 symbols", () => {
    const lfu = new LeastFrequentCollection(5);
    const testData = []
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:05:43.515Z",
      symbol: "A05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:06:43.515Z",
      symbol: "B05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:07:43.515Z",
      symbol: "C05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:08:43.515Z",
      symbol: "D05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:09:43.515Z",
      symbol: "E05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:10:43.515Z",
      symbol: "F05.SI"
    })

    testData.forEach(element => {
        lfu.put(element);
    }); 

    const response = lfu.getRecentSymbols("2019-05-05T18:11:43.515Z")
    expect(response.length).is.equal(5);
    expect(response[0].symbol).is.equal("F05.SI");
    expect(response[1].symbol).is.equal("E05.SI");
    expect(response[2].symbol).is.equal("D05.SI");
    expect(response[3].symbol).is.equal("C05.SI");
    expect(response[4].symbol).is.equal("B05.SI");
  })

  it("should return empty if all symbols were submitted before 10 minutes", () => {
    const lfu = new LeastFrequentCollection(5);
    const testData = []
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:05:43.515Z",
      symbol: "A05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:06:43.515Z",
      symbol: "B05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:07:43.515Z",
      symbol: "C05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:08:43.515Z",
      symbol: "D05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:09:43.515Z",
      symbol: "E05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:10:43.515Z",
      symbol: "F05.SI"
    })

    testData.forEach(element => {
        lfu.put(element);
    }); 

    const response = lfu.getRecentSymbols("2019-05-05T18:32:43.515Z")
    expect(response.length).is.equal(0);
  })

  it("should return frequently submitted symbols in last 10 minutes", () => {
    const lfu = new LeastFrequentCollection(5);
    const testData = []
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:05:43.515Z",
      symbol: "A05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:06:43.515Z",
      symbol: "B05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:07:43.515Z",
      symbol: "C05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:08:43.515Z",
      symbol: "D05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:09:43.515Z",
      symbol: "E05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:10:43.515Z",
      symbol: "F05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:11:43.515Z",
      symbol: "F05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:12:43.515Z",
      symbol: "F05.SI"
    })
    testData.push({
      ... mockData,
      timestamp: "2019-05-05T18:11:43.515Z",
      symbol: "E05.SI"
    })

    testData.forEach(element => {
        lfu.put(element);
    }); 

    const response = lfu.getRecentSymbols("2019-05-05T18:14:43.515Z")
    expect(response.length).is.equal(5);
    expect(response[0].symbol).is.equal("F05.SI");
    expect(response[1].symbol).is.equal("E05.SI");
    expect(response[2].symbol).is.equal("D05.SI");
    expect(response[3].symbol).is.equal("C05.SI");
    expect(response[4].symbol).is.equal("B05.SI");
  })
})