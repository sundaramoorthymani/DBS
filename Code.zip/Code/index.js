
const express = require('express');

const app = express();
const port = process.env.PORT || 5000;

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

const { LeastFrequentCollection } = require('./collection');
const lfuCollection = new LeastFrequentCollection(5);

app.post('/quote', (req, res) => {
  const { timestamp, symbol } = req.body;
  const quote = { timestamp, symbol }
  lfuCollection.put(quote)
  res.send("Stored");
});

app.get('/symbols/recent', (req, res) =>
  res.send(lfuCollection.getRecentSymbols(Date())),
);

app.listen(port, () => {
  console.log(`Server listening on http://0.0.0.0:${port}`);
});
