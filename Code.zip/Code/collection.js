
class Node {
    constructor(key, symbol) {
        this.key = key;
        this.symbol = symbol;
        this.prev = null;
        this.next = null;
    }
}

class LeastRecentCollection {
    constructor() {
        // this.capacity = 5;
        this.dic = {};
        this.head = new Node(0, 0);
        this.tail = new Node(0, 0);
        this.head.next = this.tail;
        this.tail.prev = this.head;
        this.freq = 0;
    }


    updateLatest(timestamp, timeLimit) {
        const oldFreq = this.freq
        let node = this.tail.prev;
        let count = 0;
        while (node != this.head) {
            const duration = timestamp - node.key;
            if (duration/1000 >= timeLimit * 60 || duration < 0) {
                const nextNode = node.next;
                this.head.next = nextNode
                nextNode.prev = this.head
                this.freq = count
                node = this.head
            } else {
                count += 1
                node = node.prev;
            }
        }
        return { oldFreq, count };
    }

    addNewNode(key, val) {
        if (key in this.dic) {
            this._remove(this.dic[key]);
        }
        let n = new Node(key, val);
        this._add(n);
        this.dic[key] = n;
    }

    _remove(node) {
        const p = node.prev;
        const n = node.next;
        p.next = n
        n.prev = p
        this.freq -= 1
    }

    _add(node) {
        const p = this.tail.prev;
        p.next = node;
        this.tail.prev = node
        node.prev = p
        node.next = this.tail
        this.freq += 1;
    }
}

class DLinkedList {
    constructor(capacity) {
        this.capacity = capacity;
        this.head = new LeastRecentCollection();
        this.head.prev = this.head;
        this.head.next = this.head;
        this.size = 0
    }

    append(node) {
        if (this.size >= this.capacity) {
            this.pop();
        }
        const lastNode = this.head.prev;
        this.head.prev = node;
        node.next = this.head
        lastNode.next = node
        node.prev = lastNode;
        this.size += 1;
    }

    pop(node) {
        if (this.size == 0) {
            return;
        }
        if (!node) {
            node = this.head.next;
        }
        node.prev.next = node.next
        node.next.prev = node.prev
        this.size -= 1
        return node
    }
}

class LeastFrequentCollection {
    constructor(capacity) {
        this.capacity = capacity;
        this.size = 0
        this.nodes = {};
        this.freq = {};
        this.minFreq = 1;
        this.maxFreq = [1];
    }

    freqUpdate(oldFreqVal, newFreqVal, lfuNode) {
        this.getFreqNode(oldFreqVal).pop(lfuNode);

        if (oldFreqVal == this.minFreq && this.freq[oldFreqVal].size == 0) {
            this.minFreq += 1
        }
        if (lfuNode.freq == this.maxFreq.slice(-1)[0] && this.freq[lfuNode.freq].size == 0) {
            this.maxFreq.pop();
        }

        if (newFreqVal > 0) {
            this.getFreqNode(newFreqVal).append(lfuNode);
        }
        const maxFz = Math.max(this.maxFreq.slice(-1)[0], newFreqVal);
        if (this.maxFreq.slice(-1)[0] != maxFz) {
            this.maxFreq.push(maxFz)
        }
    }

    update(lruNode) {
        let freqVal = lruNode.freq;
        this.freqUpdate(freqVal, freqVal + 1, lruNode)
    }

    put(quote) {
        const key = quote.symbol;
        const val = new Date(quote.timestamp).getTime();
        if (this.capacity == 0) {
            return
        }
        let node;
        if (key in this.nodes) {
            node = this.nodes[key];
            this.update(node);
            node.addNewNode(val, key);
        } else {
            if (this.size == this.capacity) {
                node = this.getFreqNode(this.minFreq).pop();
                delete this.nodes[node.key];
                this.size -= 1
            }
            const newNode = new LeastRecentCollection();
            newNode.addNewNode(val, key);
            this.nodes[key] = newNode;
            this.getFreqNode(newNode.freq).append(newNode);
            this.minFreq = 1
            this.size += 1
        }
    }


    getRecentSymbols(currentTime) {
        console.log(currentTime)
        const currentTimeStamp = new Date(currentTime).getTime();
        console.log(currentTimeStamp)
        
        for (let i = 0; i < Object.keys(this.maxFreq).length; i++) {
            let lruNode = this.freq[this.maxFreq[i]].head.next;
            const sizeBefore = this.freq[this.maxFreq[i]].size;

            let nodeCount = 0;
            while (nodeCount < sizeBefore) {
                const { oldFreq, count } = lruNode.updateLatest(currentTimeStamp, 10);
                const nextLRUNode = lruNode.next;
                this.freqUpdate(oldFreq, count, lruNode)
                lruNode = nextLRUNode;
                nodeCount += 1
            }
        }

        const frequentSymbols = []
        const freqKeys = Object.keys(this.freq);
        const freqLength = freqKeys.length;
        for (let i = freqLength - 1; i >= 0; i--) {
            let lruNode = this.freq[freqKeys[i]].head.prev;
            let nodeCount = 0;
            while(nodeCount < this.freq[freqKeys[i]].size) {
                frequentSymbols.push({
                    symbol: lruNode.head.next.symbol,
                    freq: lruNode.freq
                })
                nodeCount += 1
                lruNode = lruNode.prev;
                if (frequentSymbols.length > 4) {
                    return frequentSymbols;
                }
            }
        }
        return frequentSymbols;
    }

    getFreqNode(freqency) {
        if (!(freqency in this.freq)) {
            this.freq[freqency] = new DLinkedList(this.capacity);   
        }
        return this.freq[freqency];
    }
}

module.exports = {
    LeastFrequentCollection
}
